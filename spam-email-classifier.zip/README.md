# 📧 Spam Email Classifier

## Features
- Detects Spam / Not Spam emails
- Simple ML logic (Naive Bayes ready structure)
- Streamlit web app

## Run
pip install -r requirements.txt
streamlit run app.py
