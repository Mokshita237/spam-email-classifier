import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Simple demo training (replace with real dataset for better accuracy)
def train_model(X, y):
    cv = CountVectorizer()
    X_vec = cv.fit_transform(X)
    model = MultinomialNB()
    model.fit(X_vec, y)
    return model, cv
