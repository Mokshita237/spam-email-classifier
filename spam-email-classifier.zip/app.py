import streamlit as st
from predict import predict_email

st.title("📧 Spam Email Classifier")

email = st.text_area("Enter Email Content")

if st.button("Predict"):
    if email:
        result = predict_email(email)
        st.success(f"Prediction: {result}")
    else:
        st.warning("Please enter email text")
