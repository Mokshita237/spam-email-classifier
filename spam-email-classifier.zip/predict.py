import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Simple pre-trained dummy logic for demo
spam_words = ["free", "win", "prize", "click", "offer"]

def predict_email(text):
    text = text.lower()
    score = sum(word in text for word in spam_words)

    if score >= 2:
        return "Spam 🚫"
    else:
        return "Not Spam ✅"
